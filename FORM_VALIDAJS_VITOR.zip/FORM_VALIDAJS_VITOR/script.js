const form = document.querySelector('#form');
const nameInput = document.querySelector('#name');
const emailInput = document.querySelector('#email');
const passwordInput = document.querySelector('#password');
const jobSelect = document.querySelector('#job');
const messageTextarea = document.querySelector('#message');

//imprimindo no console os elementos da DOM

form.addEventListener('submit',(event)=> {
    event.preventDefault();

    //verifica se o nome está vazio
    if(nameInput.value === "") {
        alert("Por favor, preencha seu nome");
        return;
    }

    //verifica se o email está preenchido
    if(emailInput.value === "" || !isEmailValid(emailInput.value)) {
        alert("Por favor, preencha seu email");
        return;
    }

    if(validatePassword(passwordInput.value,8)) {
        alert(" A senha precisa ter no mínimo 8 digitos")
    }

    if(jobSelect.value === "") {
        alert('por favor, seleciona sua opção');
    }
    
    //verifica se a mensagem foi preenchida
    if(messageTextarea.value === "") {
        alert('Por favor, escreva uma mensagem');
    }
    
    
    form.submit();
});

function isEmailValid(emailInput) {
    //cria um regex para validar email
    var emailRegex = new RegExp(
        //usuario02@host.com.br 
        /^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]{2,}$/
    )

    if(emailRegex.test(emailInput)) {
        return true;
    }
    return false;
}

function validatePassword(password,minDigits) {
    if(password.length>=minDigits) {
        return false;
    }
    return true;
}




