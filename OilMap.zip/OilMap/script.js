(function() {
  
    var states = document.getElementsByClassName("estado")
    
    for(var i = 0; i < states.length; i++) {
      states[i].onclick = function() {
          alert(this.getAttribute('name') + ' ' + this.getAttribute('code'));
      }
    }
    
  })();

  function mostraNome() {
    let textoAlagoas = document.getElementById('texto').innerHTML = '1-BRSA-510D-AL';
    fundoDoTextoAlagoas();
  }
    
  let bolaAlagoas = document.getElementById('bola');
  bolaAlagoas.onclick = mostraNome;

  function fundoDoTextoAlagoas() {
    document.getElementById('retangulo').style.display = 'block';
  }


    
  