let circulos = [get('circulo')];
let retangulo = get('retangulo');
let texto = get('texto');
let circuloMaior = get('circuloMaior');
let circuloMenor = get('circuloMenor');
let poligono = get('poligono');
let pocos = get('pocos');
let paragrafo = get('paragrafo');
let imagemBotaoZoom = get('imagemBotaoZoom');
let borda = get('borda');
let inputPesquisa = get('pesquisa');
let botaoPesquisa = get('botaoPesquisa');
let info = get('informacoes');
let fechaInformacoes = get('fecha__informacoes');
let matoGrosso = get('mt');
let mostraPocos = false;
let zoomAtivado = false;
let temInformacoes = false;
let pocoMatoGrosso = false;

(function() {
  
    var states = document.getElementsByClassName("estado");
    
    for(var i = 0; i < states.length; i++) {
      states[15].onclick = function() {
        pocoMt();
      }
    }
    
  })()

circulos[0].onclick = mostraSeta;

  function mostraSeta() {

    texto.style.display = 'block';
    retangulo.style.display = 'block';
    poligono.style.display = 'block';
    circuloMaior.style.display = 'block';
    circuloMenor.style.display = 'block';
  if(zoomAtivado) {

    mostraInformacoes();
  }
}

pocos.onclick = function() {

  if(mostraPocos === false) {

    pocosSelecionados(circulos.length, 'block');
    mostraPocos = true;
  } else {

    pocosSelecionados(0, 'none');
    mostrarNenhum('none');
    mostraPocos = false;
  }
}

imagemBotaoZoom.onclick = function() {

  if(zoomAtivado == false) {
      
    borda.style.width = '100vw';
    borda.style.height = '100vh';
    zoomAtivado = true;
  } else {

    borda.style.width = 'auto';
    borda.style.height = '82vh'; 
    mostrarNenhum('none');
    zoomAtivado = false;
  }
}

botaoPesquisa.onclick = function() {
    
  if(inputPesquisa.value === '1-NAB-6-SE52') {
    
    mostraSeta();
    pocosSelecionados(circulos.length, 'block');
    if(zoomAtivado) {

      mostraInformacoes();
    }
  }
}

function mostraInformacoes() {

  borda.style.zIndex = '1';
  info.style.display = 'block';
  get('informacoes__bacia').innerHTML = 'Bacia: ';
  get('informacoes__bloco').innerHTML = 'Bloco: ';
  get('informacoes__campo').innerHTML = 'Campo: ';
  get('informacoes__operador').innerHTML = 'Operador: ';
  get('informacoes__estados').innerHTML = 'Estado: ';
  get('informacoes__coordenadas').innerHTML = 'Coordenadas: ';
  get('informacoes__fluidoPrincipal').innerHTML = 'Fluido Principal: ';
  get('informacoes__laminaDagua').innerHTML = 'Lâmina d agua: ';
  get('informacoes__nome').innerHTML = 'Nome: ';
  get('informacoes__tipoDePoco').innerHTML = 'Tipo de poço: ';
  get('informacoes__reclassificacao').innerHTML = 'Reclassificação: ';
  get('informacoes__situacao').innerHTML = 'Situcação: ';
  get('informacoes__inicio').innerHTML = 'Início: ';
  get('informacoes__termino').innerHTML = 'Término: ';
  get('informacoes__conclusao').innerHTML = 'Conclusão: ';
  temInformacoes = true;
}

fechaInformacoes.onclick = function() {

  if(temInformacoes) {

    mostrarNenhum('none');
  }
}
  
function pocoMt() {

  if(mostraPocos === false) {

    paragrafo.innerHTML = 'Componentes selecionados: ' + circulos.length;
    circulos[0].style.display = 'block';
    mostraPocos = true;
  } else {

    circulos[0].style.display = 'none';
    mostraPocos = false;
    paragrafo.innerHTML = 'Componentes selecionados: 0';
    mostrarNenhum('none');
  }
}

function mostrarNenhum(valor) {
    
  texto.style.display = valor;
  retangulo.style.display = valor;
  poligono.style.display = valor;
  circuloMaior.style.display = valor;
  circuloMenor.style.display = valor;
  info.style.display = valor;
}

function pocosSelecionados(valor1, valor2) {
  
  paragrafo.innerHTML = 'Componentes selecionados: ' + valor1;
  circulos[0].style.display = valor2;
}

function get(id) {
    
  return document.getElementById(id);
}