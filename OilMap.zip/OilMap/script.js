(function() {
  
    var states = document.getElementsByClassName("estado")
    
    for(var i = 0; i < states.length; i++) {
      states[i].onclick = function() {
          alert(this.getAttribute('name') + ' ' + this.getAttribute('code'));
      }
    }
    
  })();

  function mostraNome() {
    let textoAlagoas = document.getElementById('texto').innerHTML = '1-BRSA-510D-AL';
    fundoDoTextoAlagoas();
    mostraSeta();
  }
    
  let bolaAlagoas = document.getElementById('bola');
  bolaAlagoas.onclick = mostraNome;

  function fundoDoTextoAlagoas() {
    document.getElementById('retangulo').style.display = 'block';
  }

  function mostraSeta() {
    document.getElementById('triangulo').style.display = 'block';
    document.getElementById('circuloMaior').style.display = 'block';
    document.getElementById('circuloMenor').style.display = 'block';
  }

  let pocos = document.getElementById('botaoPocos');
  
  pocos.onclick = function() {
    document.getElementById('componentes').innerHTML = 'Componentes selecionados: 1';
    document.getElementById('bola').style.display = 'block';
  }

  let botaoDeZoom = document.getElementById('zoom');

  botaoDeZoom.onclick = zoomEstado;

  function zoomEstado() {
    
    let borda = document.getElementById('borda');
    borda.style.width = '100%';
    borda.style.height = '100vh';
    
    let map = document.getElementById('svg-map');
    map.style.width = '100%';
    map.style.height = '90vh';
    

    /* document.getElementById('to').style.display = 'none';
    document.getElementById('ba').style.display = 'none';
    document.getElementById('se').style.display = 'none';
    document.getElementById('pe').style.display = 'none';
    document.getElementById('al').style.display = 'none';
    document.getElementById('rn').style.display = 'none';
    document.getElementById('ce').style.display = 'none';
    document.getElementById('pi').style.display = 'none';
    document.getElementById('ma').style.display = 'none';
    document.getElementById('ap').style.display = 'none';
    document.getElementById('pa').style.display = 'none';
    document.getElementById('rr').style.display = 'none';
    document.getElementById('am').style.display = 'none';
    document.getElementById('ac').style.display = 'none';
    document.getElementById('ro').style.display = 'none';
    document.getElementById('mt').style.display = 'none';
    document.getElementById('ms').style.display = 'none';
    document.getElementById('go').style.display = 'none';
    document.getElementById('pr').style.display = 'none';
    document.getElementById('sc').style.display = 'none';
    document.getElementById('rs').style.display = 'none';
    document.getElementById('sp').style.display = 'none';
    document.getElementById('mg').style.display = 'none';
    document.getElementById('rj').style.display = 'none';
    document.getElementById('es').style.display = 'none';
    document.getElementById('df').style.display = 'none';
    document.getElementById('pb').style.display = 'none'; */
  }

  let inputPesquisa = document.getElementById('pesquisa').value;

  

    
  