(function() {
  
    var states = document.getElementsByClassName("estado")
    
    for(var i = 0; i < states.length; i++) {
      states[i].onclick = function() {
          // alert(this.getAttribute('name') + ' ' + this.getAttribute('code'));
      }
    }
    
  })()
  
  let circulo = document.getElementById('circulo');
  let retangulo = document.getElementById('retangulo');
  let texto = document.getElementById('texto'); 
  let poligono = document.getElementById('poligono');
  let circuloMaior = document.getElementById('circuloMaior');
  let circuloMenor = document.getElementById('circuloMenor');
  let pocos = document.getElementById('pocos');
  let paragrafo = document.getElementById('paragrafo');
  let imagemBotaoZoom = document.getElementById('imagemBotaoZoom');
  let borda = document.getElementById('borda');
  let map = document.getElementById('svg-map');
  let inputPesquisa = document.getElementById('pesquisa');
  let botaoPesquisa = document.getElementById('botaoPesquisa');
 //let botaoLimpaPesquisa = document.getElementById('limpaPesquisa');
  let info = document.getElementById('informacoes');
  let fechaInformacoes = document.getElementById('fecha__informacoes');
  let matoGrosso = document.getElementById('mt');
  let mostraPocos = false;
  let zoomAtivado = false;
  let temInformacoes = false;
  let pocoMatoGrosso = false;

  circulo.onclick = mostraSeta;

   function mostraSeta() {

    texto.style.display = 'block';
    retangulo.style.display = 'block';
    poligono.style.display = 'block';
    circuloMaior.style.display = 'block';
    circuloMenor.style.display = 'block';
    if(zoomAtivado) {
      mostraInformacoes();
    }
  }

  pocos.onclick = function() {

    if(mostraPocos === false) {

      paragrafo.innerHTML = 'Componentes selecionados: 1';
      circulo.style.display = 'block';

      mostraPocos = true;
    } else {

      paragrafo.innerHTML = 'Componentes selecionados: 0';
      circulo.style.display = 'none';
      texto.style.display = 'none';
      retangulo.style.display = 'none';
      poligono.style.display = 'none';
      circuloMaior.style.display = 'none';
      circuloMenor.style.display = 'none';
      info.style.display = 'none';
      /* borda.style.width = '100%'; */
      /* borda.style.height = '100vh'; */

      mostraPocos = false;
    }
  }

  imagemBotaoZoom.onclick = function() {

    if(zoomAtivado == false) {
      
      borda.style.width = '100vw';
      borda.style.height = '100vh';
    
      /* map.style.width = '100%'; */
      /* map.style.height = '100%'; */

      /* map.style.margin = 0; */

      zoomAtivado = true;
    } else {
      borda.style.width = 'auto';
      borda.style.height = '82vh'; 

      /* map.style.width = '650px'; */
      /* map.style.height = '660px'; */
      
      texto.style.display = 'none';
      retangulo.style.display = 'none';
      poligono.style.display = 'none';
      circuloMaior.style.display = 'none';
      circuloMenor.style.display = 'none';
      info.style.display = 'none';

      zoomAtivado = false;
    }
  }

  botaoPesquisa.onclick = function() {
    
    if(inputPesquisa.value === '1-NAB-6-SE52') {
      mostraSeta();
      circulo.style.display = 'block';
      paragrafo.innerHTML = 'Componentes selecionados: 1';
      if(zoomAtivado) {
        mostraInformacoes();
      }
    }
  }

  

  function mostraInformacoes() {

    /* borda.style.width = '70vw'; */
    info.style.display = 'block';
    document.getElementById('informacoes__bacia').innerHTML = 'Bacia: ';
    document.getElementById('informacoes__bloco').innerHTML = 'Bloco: ';
    document.getElementById('informacoes__campo').innerHTML = 'Campo: ';
    document.getElementById('informacoes__operador').innerHTML = 'Operador: ';
    document.getElementById('informacoes__estados').innerHTML = 'Estados: ';
    document.getElementById('informacoes__coordenadas').innerHTML = 'Coordenadas: ';
    document.getElementById('informacoes__fluidoPrincipal').innerHTML = 'Fluido Principal: ';
    document.getElementById('informacoes__laminaDagua').innerHTML = 'Lâmina d agua: ';
    document.getElementById('informacoes__nome').innerHTML = 'Nome: ';
    document.getElementById('informacoes__tipoDePoco').innerHTML = 'Tipo de poço: ';
    document.getElementById('informacoes__reclassificacao').innerHTML = 'Reclassificação: ';
    document.getElementById('informacoes__situacao').innerHTML = 'Situcação: ';
    document.getElementById('informacoes__inicio').innerHTML = 'Início: ';
    document.getElementById('informacoes__termino').innerHTML = 'Término: ';
    document.getElementById('informacoes__conclusao').innerHTML = 'Conclusão: ';
    temInformacoes = true;
  }

  fechaInformacoes.onclick = function() {

    if(temInformacoes) {
      info.style.display = 'none';
      texto.style.display = 'none';
      retangulo.style.display = 'none';
      poligono.style.display = 'none';
      circuloMaior.style.display = 'none';
      circuloMenor.style.display = 'none';
    }
  }

  

  /* botaoLimpaPesquisa.onclick = function() {

    inputPesquisa.value = '';
    texto.style.display = 'none';
    retangulo.style.display = 'none';
    poligono.style.display = 'none';
    circuloMaior.style.display = 'none';
    circuloMenor.style.display = 'none';
    info.style.display = 'none';
    borda.style.width = '100%';
    inputPesquisa.focus();
  } */


  

  matoGrosso.onclick = function() {

    if(mostraPocos === false) {
    
      circulo.style.display = 'block';
      mostraPocos = true;
    } else {
      circulo.style.display = 'none';
      mostraPocos = false;
    }
  }
