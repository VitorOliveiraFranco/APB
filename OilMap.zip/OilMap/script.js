(function() {
  
    var states = document.getElementsByClassName("estado")
    
    for(var i = 0; i < states.length; i++) {
      states[i].onclick = function() {
          // alert(this.getAttribute('name') + ' ' + this.getAttribute('code'));
      }
    }
    
  })();
    
  let bolaAlagoas = document.getElementById('bola');
  bolaAlagoas.onclick = mostraSeta;

  function mostraSeta() {
    document.getElementById('texto').innerHTML = '1-BRSA-510D-AL';
    document.getElementById('retangulo').style.display = 'block';
    document.getElementById('triangulo').style.display = 'block';
    document.getElementById('circuloMaior').style.display = 'block';
    document.getElementById('circuloMenor').style.display = 'block';
    if(zoomAtivado) {
      mostraInformacoes();
    }
  }

  let bolaAmazonas = document.getElementById('bola2');
  bolaAmazonas.onclick = mostraSeta2;

  function mostraSeta2() {
    document.getElementById('texto2').innerHTML = '1-NAB-6-SE52';
    document.getElementById('retangulo2').style.display = 'block';
    document.getElementById('triangulo2').style.display = 'block';
    document.getElementById('circuloMaior2').style.display = 'block';
    document.getElementById('circuloMenor2').style.display = 'block';
    if(zoomAtivado) {
      mostraInformacoes();
    }
  }

  let pocos = document.getElementById('botaoPocos');
  
  var mostraPocos = false;

  pocos.onclick = function() {
    if(mostraPocos === false) {
      document.getElementById('componentes').innerHTML = 'Componentes selecionados: 2';
      document.getElementById('bola').style.display = 'block';
      document.getElementById('bola2').style.display = 'block';
      mostraPocos = true;
    } else {
      document.getElementById('componentes').innerHTML = 'Componentes selecionados: 0';
      document.getElementById('bola').style.display = 'none';
      document.getElementById('bola2').style.display = 'none';
      mostraPocos = false;
    }
  }

  let botaoDeZoom = document.getElementById('zoom');

  botaoDeZoom.onclick = zoomEstado;
  var zoomAtivado = false;

  function zoomEstado() {

    let borda = document.getElementById('borda');
    let map = document.getElementById('svg-map');

    if(zoomAtivado == false) {
      
      borda.style.width = '100%';
      borda.style.height = '100vh';
    
      map.style.width = '100%';
      map.style.height = '86vh';

      document.getElementById('svg-map').style.margin = 0;

      zoomAtivado = true;
    } else {
      borda.style.width = '40.5vw';
      borda.style.height = '82vh';

      map.style.width = '650px';
      map.style.height = '660px';
      zoomAtivado = false;
    }

    /* document.getElementById('to').style.display = 'none';
    document.getElementById('ba').style.display = 'none';
    document.getElementById('se').style.display = 'none';
    document.getElementById('pe').style.display = 'none';
    document.getElementById('al').style.display = 'none';
    document.getElementById('rn').style.display = 'none';
    document.getElementById('ce').style.display = 'none';
    document.getElementById('pi').style.display = 'none';
    document.getElementById('ma').style.display = 'none';
    document.getElementById('ap').style.display = 'none';
    document.getElementById('pa').style.display = 'none';
    document.getElementById('rr').style.display = 'none';
    document.getElementById('am').style.display = 'none';
    document.getElementById('ac').style.display = 'none';
    document.getElementById('ro').style.display = 'none';
    document.getElementById('mt').style.display = 'none';
    document.getElementById('ms').style.display = 'none';
    document.getElementById('go').style.display = 'none';
    document.getElementById('pr').style.display = 'none';
    document.getElementById('sc').style.display = 'none';
    document.getElementById('rs').style.display = 'none';
    document.getElementById('sp').style.display = 'none';
    document.getElementById('mg').style.display = 'none';
    document.getElementById('rj').style.display = 'none';
    document.getElementById('es').style.display = 'none';
    document.getElementById('df').style.display = 'none';
    document.getElementById('pb').style.display = 'none'; */
  }

  let botaoPesquisa = document.getElementById('botaoPesquisa');



  botaoPesquisa.onclick = function() {
    let inputPesquisa = document.getElementById('pesquisa').value;

    if(inputPesquisa === '1-NAB-6-SE52') {
      mostraSeta2();
      document.getElementById('bola2').style.display = 'block';
      document.getElementById('componentes').innerHTML = 'Componentes selecionados: 1';
      if(zoomAtivado) {
        mostraInformacoes();
      }
      
    }
  }

  let info = document.getElementById('informacoes');

  var temInformacoes = false;

  function mostraInformacoes() {
    document.getElementById('borda').style.width = '70%';
    info.style.display = 'block';
    document.getElementById('informacoes__bacia').innerHTML = 'Bacia: ';
    document.getElementById('informacoes__bloco').innerHTML = 'Bloco: ';
    document.getElementById('informacoes__campo').innerHTML = 'Campo: ';
    document.getElementById('informacoes__operador').innerHTML = 'Operador: ';
    document.getElementById('informacoes__estados').innerHTML = 'Estados: ';
    document.getElementById('informacoes__coordenadas').innerHTML = 'Coordenadas: ';
    document.getElementById('informacoes__fluidoPrincipal').innerHTML = 'Fluido Principal: ';
    document.getElementById('informacoes__laminaDagua').innerHTML = 'Lâmina d agua: ';
    document.getElementById('informacoes__nome').innerHTML = 'Nome: ';
    document.getElementById('informacoes__tipoDePoco').innerHTML = 'Tipo de poço: ';
    document.getElementById('informacoes__reclassificacao').innerHTML = 'Reclassificação: ';
    document.getElementById('informacoes__situacao').innerHTML = 'Situcação: ';
    document.getElementById('informacoes__inicio').innerHTML = 'Início: ';
    document.getElementById('informacoes__termino').innerHTML = 'Término: ';
    document.getElementById('informacoes__conclusao').innerHTML = 'Conclusão: ';
    temInformacoes = true;
  }