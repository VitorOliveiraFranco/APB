  
  let pocos = get('pocos');
  let paragrafo = get('paragrafo');
  let imagemBotaoZoom = get('imagemBotaoZoom');
  let borda = get('borda');
  let map = get('svg-map');
  let inputPesquisa = get('pesquisa');
  let botaoPesquisa = get('botaoPesquisa');
  let infor = get('informacoes');
  let fechaInformacoes = get('fecha__informacoes');
  let matoGrosso = get('mt');
  let mostraPocos = false;
  let zoomAtivado = false;
  let temInformacoes = false;
  let pocoMatoGrosso = false;

  let circulo = [get('circulo')];
  let texto = [get('texto')]; 
  let retangulo = [get('retangulo')];
  let poligono = [get('poligono')];
  let circuloMaior = [get('circuloMaior')];
  let circuloMenor = [get('circuloMenor')];

  (function() {

    for(var i = 0; i < circulo.length; i++) {
      circulo[i].onclick = mostraSeta;
    }
    
  })()


  pocos.onclick = function() {

    if(mostraPocos === false) {
      paragrafo.innerHTML = 'Componentes selecionados: ' + circulo.length;
      for(let i = 0; i < circulo.length; i++) {
        mostrar(circulo[i], 'block');
      }
      mostraPocos = true;
    } else {
      paragrafo.innerHTML = 'Componentes selecionados: 0';
      for(let i = 0; i < circulo.length; i++) {
        mostrar(circulo[i],'none');
      }
      seta('none');
      mostrar(infor,'none');
      mostraPocos = false;
    }
  }

   function mostraSeta() {
    seta('block');
    if(zoomAtivado) {
      mostraInformacoes();
    }
  }

  imagemBotaoZoom.onclick = function() {

    if(zoomAtivado == false) {
      borda.style.width = '100vw';
      borda.style.height = '100vh';
      zoomAtivado = true;
    } else {
      borda.style.width = 'auto';
      borda.style.height = '82vh';
      seta('none');
      mostrar(infor, 'none');
      zoomAtivado = false;
    }
  }

  botaoPesquisa.onclick = function() {
    
    if(inputPesquisa.value === '1-NAB-6-SE52') {
      mostraSeta();
      for(let i = 0; i < circulo.length; i++) {
        mostrar(circulo[i], 'block');
      }
      paragrafo.innerHTML = 'Componentes selecionados: ' + circulo.length;
      if(zoomAtivado) {
        mostraInformacoes();
      }
    }
  }

  function mostraInformacoes() {

    mostrar(infor, 'block');
    get('informacoes__bacia').innerHTML = 'Bacia: ';
    get('informacoes__bloco').innerHTML = 'Bloco: ';
    get('informacoes__campo').innerHTML = 'Campo: ';
    get('informacoes__operador').innerHTML = 'Operador: ';
    get('informacoes__estados').innerHTML = 'Estados: ';
    get('informacoes__coordenadas').innerHTML = 'Coordenadas: ';
    get('informacoes__fluidoPrincipal').innerHTML = 'Fluido Principal: ';
    get('informacoes__laminaDagua').innerHTML = 'Lâmina d agua: ';
    get('informacoes__nome').innerHTML = 'Nome: ';
    get('informacoes__tipoDePoco').innerHTML = 'Tipo de poço: ';
    get('informacoes__reclassificacao').innerHTML = 'Reclassificação: ';
    get('informacoes__situacao').innerHTML = 'Situcação: ';
    get('informacoes__inicio').innerHTML = 'Início: ';
    get('informacoes__termino').innerHTML = 'Término: ';
    get('informacoes__conclusao').innerHTML = 'Conclusão: ';
    temInformacoes = true;
  }

  fechaInformacoes.onclick = function() {

    if(temInformacoes) {
      mostrar(infor, 'none');
      seta('none');
    }
  }

  matoGrosso.onclick = function() {

    if(mostraPocos === false) {
      for(let i = 0; i < circulo.length; i++) {
        mostrar(circulo[i], 'block');
      }
      mostraPocos = true;
    } else {
      for(let i = 0; i < circulo.length; i++) {
        mostrar(circulo[i], 'none');
      }
      mostraPocos = false;
    }
  }

  function get(id) {
    return document.getElementById(id);
  }

  function mostrar(variavel, valor) {
      return variavel.style.display = valor;
  }

  function seta(valor) {
      mostrar(texto[0], valor);
      mostrar(retangulo[0], valor);
      mostrar(poligono[0], valor);
      mostrar(circuloMaior[0], valor);
      mostrar(circuloMenor[0], valor);
  }