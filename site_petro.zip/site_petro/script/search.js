const inputPesquisa = document.querySelector('#inputPesquisa');
const btnPesquisa = document.querySelector('#btnPesquisa');

btnPesquisa.addEventListener('click', () => {
    if(inputPesquisa.value === '1-NAB-6-SE52'){
        poco.setAttribute('class', 'block');
    }
});
