const duvida = document.querySelector('#duvida');
const ajuda = document.querySelector('#ajuda');
let contador4 = true;

duvida.addEventListener('click', () => {
    if(contador4){
        ajuda.setAttribute('class', 'ajuda block');
        contador4 = false;
    } else {
        ajuda.setAttribute('class', 'ajuda none');
        contador4 = true;
    }
});