//const filtro = document.querySelector('#filtro');
const filtro2 = document.querySelector('#filtro2');
const imgfiltro_menu = document.querySelector('#imgfiltro_menu');
let contador3 = true;

function mostraFiltro(){
    
    if(contador3){
        filtro2.setAttribute('class', 'filtro2 block');
        contador3 = false;
    } else {
        filtro2.setAttribute('class', 'filtro2');
        contador3 = true;
    }
}

imgfiltro_menu.addEventListener('click', () => {
  mostraFiltro();  
})

