let cidade = 'Campo Largo';

cidade = cidade.toLowerCase();

let cidadeNatal = 'campo largo';

cidadeNatal = cidadeNatal.toLowerCase();

console.log(cidade === cidadeNatal);