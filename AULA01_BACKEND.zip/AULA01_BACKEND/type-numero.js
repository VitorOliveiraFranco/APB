//numero inteiros

const primeiroNumero = 10;
const segundoNumero = 5;

console.log(primeiroNumero+segundoNumero);

//ponto flutuante

const primeiroDecimal = 3.14;
const segundoDecimal = .5;

console.log(primeiroDecimal/segundoDecimal);

console.log(primeiroNumero/primeiroDecimal);

const divisao = primeiroNumero/primeiroDecimal;

console.log(divisao.toFixed(2));