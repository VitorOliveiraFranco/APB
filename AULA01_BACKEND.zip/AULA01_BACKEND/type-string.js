const nomeAluna = ' Rebeca';
const maeAluna = ' Julia';

console.log(nomeAluna);

const idadeAluno = 21;

console.log(nomeAluna * 21);

//podemos concatenar strings, e isso é de certa forma uma operação entre strings
console.log(nomeAluna + maeAluna);