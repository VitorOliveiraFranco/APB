let estados = [get('ac'), get('df'), get('sp'), get('to'), get('pe'), get('pa'), get('ma'), get('am'), get('se'), get('rn'), get('ce'), get('al'), get('pi'), get('es'), get('mt'), get('mg'), get('pb'), get('go'), get('ap'), get('rr'), get('ba'), get('rj'), get('sc'), get('ms'), get('ro'), get('rs'), get('pr')];

function get(id) {

    return document.getElementById(id);
}