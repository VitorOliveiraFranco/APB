let estados = [get('ac'),get('df'),get('sp'),get('to'),get('pe'),get('pa'),get('ma'),get('am'),get('se'),get('rn'),get('ce'),get('al'),get('pi'),get('es'),get('mt'),get('mg'),get('pb'),get('go'),get('ap'),get('rr'),get('ba'),get('rj'),get('sc'),get('ms'),get('ro'),get('rs'),get('pr')];

(function() {

    let states = document.getElementsByClassName('estado');

    for(let i = 0; i < states.length; i++) {
        states[i].onclick = function() {
            some();
            states[i].style.display = 'block';
            switch(i) {
                case 0: states[i].style.transform = 'scale(7) translate(60px, -230px)';
                break;
                case 2: states[i].style.transform = 'scale(6) translate(-350px,-490px)';
            }
        }
    }
})()

/*let zoom = get('zoom');

estados[0].onclick = function() {

    for(let i = 0; i < estados.length; i++) {

        estados[i].style.display = 'none';
    }
    estados[0].style.display = 'block';
    estados[0].style.transform = 'scale(7) translate(60px,-200px)';
}*/

function some() {
    for(let i = 0; i < estados.length; i++) {
        estados[i].style.display = 'none';
    }
}

function get(id) {

    return document.getElementById(id);
}