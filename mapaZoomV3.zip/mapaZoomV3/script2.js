document.getElementById('mais').onclick = function() {
    document.getElementById('mapa').style.transform = 'scale(1.2)';
}