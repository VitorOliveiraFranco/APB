

function calcular() {
    let a1 = parseInt(document.getElementById('a1').value);
	let razao = parseInt(document.getElementById('razao').value);
	let an = parseInt(document.getElementById('an').value);

	for(let i = 1; i <= an; i++) {
		document.getElementById('resposta').innerHTML = 'O valor do termo é: a' + i + ' ' + a1 + '<br>';
		a1 = a1 * razao;
	}
    
    
}