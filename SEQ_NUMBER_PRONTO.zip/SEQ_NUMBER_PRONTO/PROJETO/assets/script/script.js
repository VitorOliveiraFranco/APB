

function calcularPG() {
    let a1 = parseInt(document.getElementById('a1').value);
	let razao = parseInt(document.getElementById('razao').value);
	let an = parseInt(document.getElementById('an').value);

	for(let i = 1; i <= an; i++) {
		document.getElementById('resposta').innerHTML = 'O valor do termo é: a' + i + ' ' + a1 + '<br>';
		a1 = a1 * razao;
	}
    
    
}

function calcularPA() {
    let a1 = parseInt(document.getElementById('a1').value);
	let razao = parseInt(document.getElementById('razao').value);
	let an = parseInt(document.getElementById('an').value);

	for(let i = 1; i <= an; i++) {
		document.getElementById('resposta').innerHTML = 'O valor do termo é: a' + i + ' ' + a1 + '<br>';
		a1 = a1 + razao;
	}
    
    
}
function fibonacci() {

	let termo =  parseInt(document.getElementById('termo').value);
    let numeros = [1, 1];
	let resposta = document.getElementById('resposta');
    for(let i = 1; i <= termo - 2; i++) {
        if(termo <= 2) {
            resposta.innerHTML = '1';
        } else {
			numeros.push(numeros[i - 1] + numeros[i]);
			resposta.innerHTML = numeros[termo - 1];
		}
    }
}